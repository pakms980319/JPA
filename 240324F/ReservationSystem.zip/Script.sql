create table Exam_Visitor (
	visitor_id	varchar(255)	primary key,
	email		varchar(50)		default null,
	user_device	varchar(15)		not null,
	referer		varchar(100)	not null,
	request_uri	varchar(100)	not null,
	client_ip	varchar(50)		not null
);



drop table exam_visitor;

create table exam_visitor (
	visitorId	varchar(255)	primary key,
	email		varchar(50)		default null,
	userDevice	varchar(15)		not null,
	referer		varchar(100)	not null,
	requestURI	varchar(100)	not null,
	clientIP	varchar(50)		not null
);

select * from exam_visitor;

drop table book;

create table Book (
	isbn	varchar(10)	primary key,
	title	varchar(100)	not null,
	price	int	not null,
	author	varchar(30)	not null,
	press	varchar(30)	not null
);

select * from book;

drop table engmanmember;

CREATE TABLE EngmanMember (
	id			bigint			PRIMARY KEY	AUTO_INCREMENT,
	email 		varchar(100) 	NOT NULL,
	passwd 		varchar(60) 	NOT NULL,
	alias 		varchar(25) 	NOT NULL,
	imagePath 	varchar(255) 	NULL,
	memberRole 	varchar(20) 	NOT NULL,
	name		varchar(10) 	NOT NULL,
	phone 		varchar(20) 	NOT NULL 	DEFAULT '',
	sex 		char(1) 		NOT NULL 	DEFAULT 'X',
	birthDate 	DATE 			NOT NULL,
	regDate 	TIMESTAMP 		NOT NULL 	DEFAULT CURRENT_TIMESTAMP,
	updateDate 	TIMESTAMP 		NOT NULL 	DEFAULT CURRENT_TIMESTAMP		ON UPDATE CURRENT_TIMESTAMP
)auto_increment=1501;

select * from engmanmember;

-- --------------------------------------------------- 
-- 240224 
create table ExamUser1 (
	id			BIGINT			primary key auto_increment,
	email		VARCHAR(50)		not null,
	passwd		VARCHAR(60) 	not null,
	name		VARCHAR(10)		not null,
	phone		VARCHAR(11)		not null,
	address1	VARCHAR(20)		not null,
	address2	VARCHAR(60)		not null,
	postalCode	vARCHAR(5)		not null
) auto_increment = 1501;

select * from EXAMUSER1;




create table ExamUser (
	id			BIGINT			primary key auto_increment,
	email		VARCHAR(50)		not null,
	passwd		VARCHAR(60) 	not null,
	name		VARCHAR(10)		not null,
	phone		VARCHAR(11)		not null
) auto_increment = 1501;

create table ExamAddress (
	userId		BIGINT			not null,
	address1	VARCHAR(20)		not null,
	address2	VARCHAR(60)		not null,
	postalCode	vARCHAR(5)		not null,
	constraint ExamAddress_userId_FK foreign key (userId) references ExamUser (id)
)

select * from EXAMUSER;
select * from ExamAddress;

-- ========================================
-- 2024-02-25

-- ========================================
-- LibraryMember
-- ========================================
create table LibraryMember (
	email		varchar(30)		primary key,
	name		varchar(20)		not null,
	lendingAuth	bool			not null default true
);

-- ========================================
-- LibraryCard
-- ========================================
create table LibraryCard (
	cardNum		varchar(10)		primary key,
	ownerEmail	varchar(30)		not null,
	enabled		bool			not null default true,
	expiryDate	Date			not null,
	constraint LibraryCard_ownerEmail_FK foreign key(ownerEmail) references LibraryMember(email)
);

select * from LIBRARYCARD;
select * from librarymember;

-- ========================================




-- =====================================
-- 240302 실습 
-- =====================================

-- =====================================
-- Partner
-- =====================================
create table Partner (
	pId				bigint				primary key auto_increment,
	name			varchar(45)			not null,
	crn				varchar(100)		not null,
	partnerType		bool				not null default true,
	phone			varchar(45)			not null,	
	homePage		varchar(100)		not null,
	status			varchar(50)			not null,
	repName			varchar(100)		not null,
	regDate			TIMESTAMP			not null	default CURRENT_TIMESTAMP,
	updateDate		TIMESTAMP			not null	default CURRENT_TIMESTAMP		on update CURRENT_TIMESTAMP
)auto_increment=1501;

-- =====================================
-- Address
-- =====================================
create table Address (
	aId				bigint				primary key auto_increment,
	pId				bigint				not null,
	district		varchar(45)			not null,
	address1		varchar(45)			not null,
	address2		varchar(45)			not null,
	postalCode		varchar(45)			not null,
	regDate			TIMESTAMP			not null	default CURRENT_TIMESTAMP,
	updateDate		TIMESTAMP			not null	default CURRENT_TIMESTAMP		on update CURRENT_TIMESTAMP,
	constraint Address_pId_FK foreign key(pId) references Partner(pId)
)auto_increment=1501;

select * from Partner;
select * from Address;



drop table Partner;
drop table Address;


drop table movie;
drop table moviedetail;

-- =====================================
-- Moive
-- =====================================
create table Movie (
	id				bigint				primary key auto_increment,
	title			varchar(100)		not null,
	poster			varchar(100)		null,
	genre			varchar(30)			not null,
	director		varchar(30)			null,	
	filmCast		varchar(30)			not null,
	openYear		Date				not null
)auto_increment=1501;

-- =====================================
-- MovieDetail
-- =====================================
create table MovieDetail (
	movieId			bigint				primary key,
	synopsis		varchar(100)		not null,
	grade			bigint				not null	default 0,
	prize			varchar(30)			null,
	constraint MovieDetail_movieId_FK foreign key(movieId) references Movie(id)
)auto_increment=1501;

select * from movie;
select * from moviedetail;




-- =====================================
-- 24/03/09
-- JPA 1차시
-- =====================================

-- =====================================
-- PartnerAdditional
-- =====================================
create table PartnerAdditional (
	partnerCode		bigint				primary key,
	partnerUri		varchar(100)		not null,
	adminId			varchar(50)			not null,
	passwd			varchar(50)			not null,
	repImagePath	varchar(100)		null,
	intro			varchar(100)		null,
	regDate			TIMESTAMP			not null	default CURRENT_TIMESTAMP,
	updateDate		TIMESTAMP			not null	default CURRENT_TIMESTAMP		on update CURRENT_TIMESTAMP,
	constraint PartnerAdditional_partnerCode_FK foreign key(partnerCode) references Partner(pId)
);

drop table partneradditional;

select * from partnerAdditional;
select * from Partner;
select * from Address;

delete from Partner;
delete from Address;

-- =====================================
-- 24/03/10
-- JPA 2차시
-- =====================================

-- =====================================
-- Country
-- =====================================
CREATE TABLE Country (
	id				BIGINT			PRIMARY key		AUTO_INCREMENT,
	name			VARCHAR(30)		NOT NULL,
	capital			VARCHAR(30)		NULL,
	population		BIGINT			NOT NULL		DEFAULT 0,
	regDate			TIMESTAMP		not null		default CURRENT_TIMESTAMP,
	updateDate		TIMESTAMP		not null		default CURRENT_TIMESTAMP		on update CURRENT_TIMESTAMP
)auto_increment=1001;
drop TABLE COUNTRY;
select * from Country;

-- =====================================
-- City
-- =====================================
create table CITY (
	id				BIGINT			primary key		auto_increment,
	countryId		BIGINT			not null,
	name			VARCHAR(30)		not null,
	climate			varchar(100)	null,
	travel			varchar(100)	not null,
	regDate			TIMESTAMP		not null		default CURRENT_TIMESTAMP,
	updateDate		TIMESTAMP		not null		default CURRENT_TIMESTAMP		on update CURRENT_TIMESTAMP,
	constraint City_countryId_FK foreign key (countryId) references Country(id)
)auto_increment=3001;
drop TABLE City;
select * from City;
delete from city;

-- =====================================
-- City
-- =====================================



-- =====================================
-- 24/03/16
-- JPA 1차시
-- =====================================

-- =====================================
-- MemberShip
-- =====================================
create table MemberShip (
	id				BIGINT			primary key		auto_increment,
	mid				BIGINT			not null,
	title			VARCHAR(100)	not null,
	expired			bool			not null,
	startDate		varchar(100)	not null,
	endDate			TIMESTAMP		not null		default CURRENT_TIMESTAMP,
	regDate			TIMESTAMP		not null		default CURRENT_TIMESTAMP		on update CURRENT_TIMESTAMP,
	constraint MemberShip_mid_FK foreign key (mid) references MemberShip(id)
)auto_increment=3001;
drop TABLE MemberShip;
select * from MemberShip;
delete from MemberShip;




-- =====================================
-- 24/03/16
-- JPA 1차시
-- =====================================

-- =====================================
-- Programmer
-- =====================================
create table Programmer (
	id				BIGINT			primary key		auto_increment,
	name			varchar(30)		not null,
	email			VARCHAR(30)		not null,
	updateDate		TIMESTAMP		not null		default CURRENT_TIMESTAMP,
	regDate			TIMESTAMP		not null		default CURRENT_TIMESTAMP		on update CURRENT_TIMESTAMP
)auto_increment=3001;

drop TABLE Programmer;
select * from Programmer;
delete from Programmer;

-- =====================================
-- ProgrammerSkill
-- =====================================
create table ProgrammerSkill (
	programmerId	BIGINT			not null,
	listIndex		INT				not null,
	skill			varchar(30)		not null,
	constraint ProgrammerSkill_programmerId_FK foreign key (programmerId) references Programmer(id)
);

drop TABLE ProgrammerSkill;

select * from ProgrammerSkill;
delete from ProgrammerSkill;



-- =====================================
-- 24/03/17
-- JPA 2차시
-- =====================================

-- =====================================
-- Dealership
-- =====================================
create table Dealership (
	id				BIGINT			primary key		auto_increment,
	name			varchar(30)		not null,
	location		VARCHAR(100)	not null,
	phone			varchar(30)		NOT NULL,
	regDate			TIMESTAMP		not null		default CURRENT_TIMESTAMP,
	updateDate		TIMESTAMP		not null		default CURRENT_TIMESTAMP		on update CURRENT_TIMESTAMP
)auto_increment=1001;

drop TABLE Dealership;
select * from Dealership;
delete from Dealership;

-- =====================================
-- Car
-- =====================================
create table Car (
	id				BIGINT			primary key		auto_increment,
	dealerId		bigint,
	modelName		varchar(100)	not null,
	modelNum		VARCHAR(100)	not null,
	modelYear		int				NOT NULL,
	maker			varchar(30)		NOT NULL,
	regDate			TIMESTAMP		not null		default CURRENT_TIMESTAMP,
	updateDate		TIMESTAMP		not null		default CURRENT_TIMESTAMP		on update CURRENT_TIMESTAMP,
	constraint Car_dealerId_FK foreign key (dealerId) references Dealership(id)
)auto_increment=3001;

drop TABLE Car;

select * from Car;
delete from Car;

-- =====================================
-- 24/03/23
-- JPA 1차시
-- =====================================

-- =====================================
-- PartnerRequest
-- =====================================
CREATE TABLE PartnerRequest (
	id				BIGINT			PRIMARY KEY		AUTO_INCREMENT,
	pId				BIGINT,
	ask				VARCHAR(500)	NOT NULL,
	askType			BOOLEAN			NOT NULL,
	regdate			TIMESTAMP		NOT NULL		DEFAULT CURRENT_TIMESTAMP,
	updateDate		TIMESTAMP		NOT NULL		DEFAULT CURRENT_TIMESTAMP		ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT PartnerReqeust_pId_FK FOREIGN KEY (pId) REFERENCES Partner(pId)
) auto_increment=1001;

SELECT * FROM PartnerRequest;
select * from partner;
DELETE * FROM PartnerRequest;

DROP TABLE PartnerRequest;



-- =====================================
-- Customer
-- =====================================
create table Customer (
	cId				BIGINT			primary key			auto_increment,
	aId				BIGINT,
	firstName		VARCHAR(30)		not null,
	lastName		VARCHAR(30)		not null,
	phone			VARCHAR(30)		not null,
	birthDate		DATE			not null,
	CONSTRAINT Customer_aId_FK FOREIGN KEY (aId) REFERENCES Address(aId)
)auto_increment=1001;

SELECT * FROM customer;
DELETE * FROM customer;
DROP TABLE customer;


-- =====================================
-- Address
-- =====================================
create table Address (
	aId				BIGINT			primary key			auto_increment,
	region			VARCHAR(30)		not null,
	street1			VARCHAR(100)	not null,
	street2			VARCHAR(100)	not null,
	zipCode			VARCHAR(30)		not null
)auto_increment = 2001;

SELECT * FROM Address;
DELETE * FROM Address;
DROP TABLE Address;

-- =====================================
-- Property
-- =====================================
create table Property (
	pId				BIGINT			primary key			auto_increment,
	name			varchar(50)		not null,
	address			varchar(100)	not null
)auto_increment = 3001;

SELECT * FROM Property;
DELETE * FROM Property;
DROP TABLE Property;

-- =====================================
-- HotelReview
-- =====================================
create table HotelReview (
	hId				BIGINT			primary key			auto_increment,
	pId				BIGINT,
	review			varchar(500)	not null,
	constraint HotelReview_pId_FK foreign key(pId) references Property(pId)
)auto_increment = 4001;

SELECT * FROM HotelReview;
DELETE * FROM HotelReview;
DROP TABLE HotelReview;


-- =====================================
-- Room
-- =====================================
create table Room (
	rId				BIGINT			primary key			auto_increment,
	pId				BIGINT,
	roomNum			int				not null,
	name			varchar(50)		not null,
	capcity			int				not null,
	price			double			not null,
	intro			varchar(500)	not null,
	constraint Room_pId_FK foreign key(pId) references Property(pId)
)auto_increment = 5001;

SELECT * FROM Room;
DELETE * FROM Room;
DROP TABLE Room;


-- =====================================
-- Room
-- =====================================
create table Room (
	rId				BIGINT			primary key			auto_increment,
	pId				BIGINT,
	roomNum			int				not null,
	name			varchar(50)		not null,
	capcity			int				not null,
	price			double			not null,
	intro			varchar(500)	not null,
	constraint Room_pId_FK foreign key(pId) references Property(pId)
)auto_increment = 5001;

SELECT * FROM Room;
DELETE * FROM Room;
DROP TABLE Room;


-- =====================================
-- ReservationRoom
-- =====================================
create table ReservationRoom (
	rrId			BIGINT			primary key			auto_increment,
	rId				BIGINT,

	constraint ReservationRoom_pId_FK foreign key(rId) references Room(rId)
)auto_increment = 6001;

SELECT * FROM ReservationRoom;
DELETE * FROM ReservationRoom;
DROP TABLE ReservationRoom;