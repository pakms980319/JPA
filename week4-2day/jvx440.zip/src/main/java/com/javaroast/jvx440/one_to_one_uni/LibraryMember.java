package com.javaroast.jvx440.one_to_one_uni;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Entity
@Getter
@Setter
@ToString
public class LibraryMember {
	@Id
	private String email;
	private String name;
	private boolean lendingAuth;	// 대출 권한, default = true
	
}
