package com.javaroast.jvx440.exam.id.Room;

import org.springframework.data.jpa.repository.JpaRepository;

public interface HotelRoomRepository extends JpaRepository<HotelRoom, Long> {

}
