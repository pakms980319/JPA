package com.javaroast.jvx440.exam.one_to_one_bi;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.OneToOne;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Entity
@Getter
@Setter
@ToString
public class LibraryMember {
	@Id
	private String email;
	private String name;
	private boolean lendingAuth;	// 대출 권한, default = true
	
	@OneToOne(mappedBy = "owner")
	private LibraryCard card;	
}
