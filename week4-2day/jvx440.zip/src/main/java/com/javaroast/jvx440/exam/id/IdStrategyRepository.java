package com.javaroast.jvx440.exam.id;

import org.springframework.data.jpa.repository.JpaRepository;

public interface IdStrategyRepository extends JpaRepository<IdStrategy, Long> {

}
