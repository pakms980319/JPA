package com.javaroast.jvx440.one_to_one_uni.repository;

import org.springframework.data.repository.CrudRepository;

import com.javaroast.jvx440.one_to_one_uni.LibraryMember;


public interface LibraryMemberRepository extends CrudRepository<LibraryMember, String>{

}
