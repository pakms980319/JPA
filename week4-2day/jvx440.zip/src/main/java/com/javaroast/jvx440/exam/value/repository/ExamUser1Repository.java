package com.javaroast.jvx440.exam.value.repository;

import org.springframework.data.repository.CrudRepository;

import com.javaroast.jvx440.exam.value.domain.ExamUser1;

public interface ExamUser1Repository extends CrudRepository<ExamUser1, Long> {
	
}