package com.javaroast.jvx440.exam.one_to_one_bi;

import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Entity
@Getter
@Setter
@ToString
public class LibraryCard {
	@Id
	private String cardNum;  // 카드 번호
	@OneToOne
	@JoinColumn(name = "ownerEmail")
	private LibraryMember owner;
	private boolean enabled;  // 카드 사용가능 여부, default = true
	
	@Temporal(TemporalType.DATE)
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	@Column(updatable = false)
	private Date expiryDate;  // 만료날짜
}
