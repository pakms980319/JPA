package com.javaroast.jvx440.reservation.domain;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Property {
	private String name;
	private String address;
}
