package com.javaroast.jvx440.exam.collection;

import org.springframework.data.repository.CrudRepository;

public interface ProgrammerRepository extends CrudRepository<Programmer, Long> {

}
