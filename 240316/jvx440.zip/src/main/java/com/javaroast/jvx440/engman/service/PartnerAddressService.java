package com.javaroast.jvx440.engman.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.javaroast.jvx440.engman.common.domain.Address.Address;
import com.javaroast.jvx440.engman.common.domain.Address.AddressRepository;
import com.javaroast.jvx440.engman.partners.domain.Partner.Partner;
import com.javaroast.jvx440.engman.partners.domain.Partner.PartnerRepository;

@Service
public class PartnerAddressService {
	@Autowired
	private PartnerRepository partnerRepository;
	@Autowired
	private AddressRepository addressRepository;
	
	public void addPartner(Partner partner) {
		partnerRepository.save(partner);
	}
	
	public Optional<Partner> getPartnerById(long id) {
		Optional<Partner> partner = partnerRepository.findById(id); 
		return partner;
	}
	
	
	public List<Partner> getAllPartnerList() {
		return (List<Partner>)partnerRepository.findAll();
	}
	
	public Optional< List<Address> > findByDistrict(String district) {
        List<Address> addressList = addressRepository.findByDistrict(district);
        return Optional.ofNullable(addressList);
    }
	
}
