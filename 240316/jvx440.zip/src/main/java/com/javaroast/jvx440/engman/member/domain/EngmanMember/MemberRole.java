package com.javaroast.jvx440.engman.member.domain.EngmanMember;

public enum MemberRole {
	USER,
	ADMIN,
	MEMBER
}
