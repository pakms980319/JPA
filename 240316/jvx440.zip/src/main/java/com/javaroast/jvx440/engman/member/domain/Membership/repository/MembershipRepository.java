package com.javaroast.jvx440.engman.member.domain.Membership.repository;

import org.springframework.data.repository.CrudRepository;

import com.javaroast.jvx440.engman.member.domain.Membership.MemberShip;

public interface MembershipRepository extends CrudRepository<MemberShip, Long>{

}
