//package com.javaroast.jvx440.engman.member.domain;
//
//public enum MemberRole {
//	USER,
//	ADMIN,
//	MEMBER
//}
