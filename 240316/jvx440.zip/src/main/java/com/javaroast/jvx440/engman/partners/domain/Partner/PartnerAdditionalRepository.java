package com.javaroast.jvx440.engman.partners.domain.Partner;

import org.springframework.data.repository.CrudRepository;

public interface PartnerAdditionalRepository extends CrudRepository<PartnerAdditional, Long> {

}
