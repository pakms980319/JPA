package com.javaroast.jvx440.exam.sharekey;

import org.springframework.data.repository.CrudRepository;

public interface MovieDetailRepository extends CrudRepository<MovieDetail, Long> {

}
