package com.javaroast.jvx440.common.util;

import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.Date;

public class DateUtil {
	public static Date parseDate(int year) {
		String dateStr = String.valueOf(year);
		SimpleDateFormat format = new SimpleDateFormat("yyyy");
		ParsePosition pos = new ParsePosition(0);
		return format.parse(dateStr, pos);
	}
	
	public static Date parseDate(String dateStr) {
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		ParsePosition pos = new ParsePosition(0);
		return format.parse(dateStr, pos);
	}
	
	public static String getFormatDate(Date date, String pattern) {
		SimpleDateFormat format = new SimpleDateFormat(pattern);
		return format.format(date);
	}
}
