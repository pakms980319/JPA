package com.javaroast.jvx440.engman.partners.domain.Partner;

import java.util.Date;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;
import org.springframework.format.annotation.DateTimeFormat;

import com.javaroast.jvx440.engman.common.domain.Address.Address;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToOne;
import jakarta.persistence.PrimaryKeyJoinColumn;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Entity(name = "partner")
@Table(name = "Partner")
@Getter
@Setter
@ToString(of = {"name", "crn", "partnerType", "phone", "homePage", "status", "repName", "regDate", "updateDate"})
public class Partner {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long pId;			// partner Id
	private String name;		// 업체명
	private String crn;			// 사업자 등록번호
	private boolean partnerType;	// 1 학원 2 학교
	private String phone;		// 연락처
	private String homePage;	// 홈페이지
	private String status;		// 상태
	private String repName;		// 대표자명
	
	@Column(updatable = false)
	@Temporal(TemporalType.TIMESTAMP)
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	@CreationTimestamp
	private Date regDate;		// 등록날짜
	@Temporal(TemporalType.DATE)
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	@UpdateTimestamp
	private Date updateDate;	// 수정날짜
	
//	@Column(name = "ownerId")
//    private Long ownerId;        // 외래 키
	
	
	@OneToOne(mappedBy = "partner", cascade = CascadeType.PERSIST)
	private Address address;	// 주소
	
	@OneToOne(mappedBy = "partner", cascade = CascadeType.PERSIST)
	@PrimaryKeyJoinColumn
	private PartnerAdditional partnerAdditional;
	
	public void setAddress(Address addr) {
		this.address = addr;
		addr.setPartner(this);
	}
}
