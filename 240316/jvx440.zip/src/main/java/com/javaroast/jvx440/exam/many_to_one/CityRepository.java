package com.javaroast.jvx440.exam.many_to_one;

import java.util.List;

import org.springframework.data.jdbc.repository.query.Query;
import org.springframework.data.repository.CrudRepository;

public interface CityRepository extends CrudRepository<City, Long> {
	@Query("SELECT c FROM City c LEFT JOIN Country c2 ON c2.id=c.country.id WHERE c2.name= ?1")
	List<City> findByCountryName(String name);
}
