package com.javaroast.jvx440.exam.many_to_one;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CountryTravelService {
	@Autowired
	private CountryRepository countryRepo;
	
	@Autowired
	private CityRepository cityRepo;
	
	public Country addCountry(Country country) {
		return countryRepo.save(country);
	}
	
	public Country getCountryByName(String name) {
		return countryRepo.findByName(name).orElse(null);
	}
	
	public City addCity(City city) {
		if (city == null) {
			throw new RuntimeException("city정보가 없습니다.");
		}
		
		Country country = city.getCountry();
		if (country.getId() == 0) {
			// 화면에서 country 정보를 그대로 저장하여 가져온 경우 DB에서 가져온 정보가 아니기에
			// id 정보가 없을 것이다
			// 그래서 DB 에서 country 정보를 가져오는 작업을 추가해준다
			country = getCountryByName(country.getName());
			if (country == null) {
				throw new RuntimeException("도시를 등록하기 위해서는 먼저 해당 국가가"
						+ "등록되어 있어야 합니다.");
			}
		}
		return cityRepo.save(city);
	}
	
	public List<City> getCityListByCountryName(String name) {
		return cityRepo.findByCountryName(name);
	}
}
