package com.javaroast.jvx440.exam.one_to_one_bi;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository("memberRepository")
public interface LibraryMemberRepository extends CrudRepository<LibraryMember, String>{

}
