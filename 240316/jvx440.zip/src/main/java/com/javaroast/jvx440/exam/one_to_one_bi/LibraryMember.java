package com.javaroast.jvx440.exam.one_to_one_bi;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Entity(name = "member")
@Table(name = "LibraryMember")
@Getter
@Setter
public class LibraryMember {
	@Id
	private String email;
	private String name;
	private boolean lendingAuth;	// 대출 권한, default = true
	
	@OneToOne(mappedBy = "owner")
	private LibraryCard card;

	@Override
	public String toString() {
		return "LibraryMember [email=" + email + ", name=" + name + ", lendingAuth=" + lendingAuth + "]";
	}	
	
	
}
