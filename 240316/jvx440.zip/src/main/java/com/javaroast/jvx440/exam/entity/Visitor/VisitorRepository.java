package com.javaroast.jvx440.exam.entity.Visitor;

import org.springframework.data.repository.CrudRepository;

public interface VisitorRepository extends CrudRepository<Visitor, String> {

}
