package com.javaroast.jvx440.reservation.domain;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Receipt {
	// 청구 내역 정보
	
}
