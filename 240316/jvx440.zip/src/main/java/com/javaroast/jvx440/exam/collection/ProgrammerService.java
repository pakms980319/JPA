package com.javaroast.jvx440.exam.collection;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class ProgrammerService {
	@Autowired
	private ProgrammerRepository programmerRepo;
	
	public Programmer addProgrammer(Programmer programmer) {
		return programmerRepo.save(programmer);
	}
	
	public Programmer getProgrammer(long id) {
		return programmerRepo.findById(id).orElse(null);
	}
	
	@Transactional
	public Programmer modifySkills(List<String> newSkills, long programmerId) {
		Programmer programmer = getProgrammer(programmerId);
		programmer.getSkills().clear();
		programmer.setSkills(newSkills);
		return programmerRepo.save(programmer);
	}
	
	@Transactional
	public Programmer modifySkill(int idx, String newSkill, long programmerId) {
		Programmer programmer = getProgrammer(programmerId);
		programmer.getSkills().set(idx, newSkill);
		return programmerRepo.save(programmer); 
	}
	
}
