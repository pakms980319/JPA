package com.javaroast.jvx440.exam.many_to_one;

import java.util.Optional;

import org.springframework.data.repository.CrudRepository;

public interface CountryRepository extends CrudRepository<Country, Long> {
	Optional<Country> findByName(String name);
}
