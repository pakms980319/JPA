package com.javaroast.jvx440.exam.value.repository;

import org.springframework.data.repository.CrudRepository;

import com.javaroast.jvx440.exam.value.domain.ExamUser;

public interface ExamUserRepository extends CrudRepository<ExamUser, Long>{
}
