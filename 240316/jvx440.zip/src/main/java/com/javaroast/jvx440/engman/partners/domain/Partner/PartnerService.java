package com.javaroast.jvx440.engman.partners.domain.Partner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.javaroast.jvx440.engman.common.domain.Address.AddressRepository;

@Service
public class PartnerService {
	@Autowired
	private PartnerRepository partnerRepo;
	@Autowired
	private PartnerAdditionalRepository partnerAdditionalRepo;
	@Autowired
	private AddressRepository addressRepo;
	
	public Partner addPartner(Partner partner) {
		partner = partnerRepo.save(partner);
		return partner;
	}
}
