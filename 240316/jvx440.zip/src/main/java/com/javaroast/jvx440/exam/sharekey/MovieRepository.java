package com.javaroast.jvx440.exam.sharekey;

import org.springframework.data.repository.CrudRepository;

public interface MovieRepository extends CrudRepository<Movie, Long>{

}
