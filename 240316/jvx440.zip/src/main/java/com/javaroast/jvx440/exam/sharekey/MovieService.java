package com.javaroast.jvx440.exam.sharekey;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class MovieService {
	@Autowired
	private MovieRepository movieRepository;
	@Autowired
	private MovieDetailRepository movieDetailRepository;
	
	@Transactional
	public Movie addMoive(Movie movie) {
		movie = movieRepository.save(movie);
		movieDetailRepository.save(movie.getDetail());
		return movie;
	}
}
