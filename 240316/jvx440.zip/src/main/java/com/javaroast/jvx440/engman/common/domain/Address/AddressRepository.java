package com.javaroast.jvx440.engman.common.domain.Address;

import java.util.List;

import org.springframework.data.jdbc.repository.query.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository("adressRepository")
public interface AddressRepository extends CrudRepository<Address, Long> {
	@Query("SELECT p FROM Partner p INNER JOIN Address a ON a.partner.id = p.id WHERE a.district = ?1")
	List<Address> findByDistrict(String district);
}
