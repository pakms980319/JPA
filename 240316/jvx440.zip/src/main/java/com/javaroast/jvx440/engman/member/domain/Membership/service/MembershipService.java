package com.javaroast.jvx440.engman.member.domain.Membership.service;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.javaroast.jvx440.engman.member.domain.EngmanMember.EngmanMember;
import com.javaroast.jvx440.engman.member.domain.Membership.MemberShip;
import com.javaroast.jvx440.engman.member.domain.Membership.repository.MembershipRepository;
import com.javaroast.jvx440.engman.member.service.EngmanMemberService;

@Service
public class MembershipService {
	@Autowired
	private EngmanMemberService memberService;
	
	public MemberShip createMembership(String title, Date startDate, Date endDate) {
		MemberShip ms = new MemberShip();
		ms.setTitle(title);
		ms.setStartDate(startDate);
		ms.setEndDate(endDate);
		return ms;
	}
	
	@Transactional
	public MemberShip addMemberShip(MemberShip ms, String email) {
		EngmanMember member = memberService.getMemberByEmail(email);
		ms.setMember(member);
		return ms;
	}
	
	
}
