package com.javaroast.jvx440.exam.sharekey;

import java.util.Date;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToOne;
import jakarta.persistence.PrimaryKeyJoinColumn;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Entity
@Getter
@Setter
@ToString
public class Movie {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id; 
	
	private String title;		// 영화 제목
	private String poster;		// 포스터 이미지
	private String genre;		// 장르
	private String director;	// 감독
	private String filmCast;	// 출연지
	private Date openYear;		// 개봉연도
	
	@OneToOne(mappedBy = "movie")
	@PrimaryKeyJoinColumn
	private MovieDetail detail;

	public Movie() {
		// TODO Auto-generated constructor stub
	}
	
	public Movie(String title, String poster, String genre, String director, String filmCast, Date openYear,
			MovieDetail detail) {
		super();

		this.title = title;
		this.poster = poster;
		this.genre = genre;
		this.director = director;
		this.filmCast = filmCast;
		this.openYear = openYear;
		this.detail = detail;
	}
	
	public Movie(String title, String poster, String genre, String director, String filmCast, Date openYear,
			String synopsis, long grade, String prize) {
		super();

		this.title = title;
		this.poster = poster;
		this.genre = genre;
		this.director = director;
		this.filmCast = filmCast;
		this.openYear = openYear;
		this.detail = new MovieDetail(this, synopsis, grade, prize);
	}
	
	
}
