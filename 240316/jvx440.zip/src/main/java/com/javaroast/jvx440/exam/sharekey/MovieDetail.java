package com.javaroast.jvx440.exam.sharekey;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.MapsId;
import jakarta.persistence.OneToOne;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
public class MovieDetail {
	@Id
	private long movieId;
	
	@MapsId
	@OneToOne
	@JoinColumn(name = "movieId")
	private Movie movie;
	
	private String synopsis;		// 줄거리
	private long grade;				// 평점
	private String prize;			// 수상내역
	
	protected MovieDetail(Movie moive, String synopsis, long grade, String prize) {
		this.movie = moive;
		this.synopsis = synopsis;
		this.grade = grade;
		this.prize = prize;
	}
	
	
}
