package com.javaroast.jvx440.exam.collection;

import java.util.Date;
import java.util.List;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;
import org.springframework.format.annotation.DateTimeFormat;

import jakarta.persistence.CollectionTable;
import jakarta.persistence.Column;
import jakarta.persistence.ElementCollection;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OrderColumn;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/*
 * List<String> skills 는 테이블에 어떻게 저장되는가?
 * 컬럼이 collection으로 되어있다면 따로 테이블을 만들어서 처리하도록 할 수 있다 (@ElementCollection)
 * 이 때 이 table은 값만 가지고 있는 table이다
 * 
 * Programmer과 ProgrammerSkill은 다대원 관계이다
 * 이럴때 jpa는 lazy loading을 사용한다
 * skill 부분만 빼고 가져온다는 얘기 (처음 가져올 때)
 * 그래서 toString으로 찍을려고하면 에러가 발생한다
 * 
 * 나중에 skill을 가져오려고하려면 transaction 상황이어야 한다
 * 
 * hibernate를 할 땐 begin - end를 사용한다 (사이에 insert, update, delete 등 사용)
 * 이걸 transaction 상황이라고 한다
 * 
 * spring data jpa에서는 위 작업을 할 때 @Transactional 어노테이션을 작성한다
 * 
 * 왜 transaction 상황이 발생하는가? 내가 데이터를 바꿀려고 할 때 다른 사람이 참조하고 있을수도 있기때문
 * 
 * 서비스테스트에서 getProgrammer()을 할 때
 * 처음에 Programmer을 가져오고 다음에 skill을 가져와야하는데
 * 이를 한번에 수행하려면 명시적 작업이 필요하다
 * @Transactional 어노테이션 추가 ( 두 개의 단위를 하나로 수행하라 )
 * 
 * 다른 방법으로는 
 * @ElementCollection을
 * @ElementCollection(fetch = FetchType.EAGER)		으로 수정한다
 * => @Transactional 어노테이션을 추가하지 않아도 Skill을 읽어온다
 * 
 * 
 * skill의 update는 두 가지 방식으로 할 수 있다
 * 전체 변경과 일부 변경
 * */

@Entity
@Setter
@Getter
@ToString
public class Programmer {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	private String name;
	private String email;
	@ElementCollection(fetch = FetchType.EAGER)											// 매핑 대상 값 콜렉션임을 정의
	@CollectionTable(											// 컬렉션 저장 시 사용할 테이블 정의
			name = "ProgrammerSkill",							// 테이블 명
			joinColumns = @JoinColumn(name="programmerId"))		// 부모 엔티티를 참조할 컬럼명
	@OrderColumn(name="listIndex")								// List의 인덱스를 저장할 컬럼명
	@Column(name = "skill")										// 컬렉션의 개별요소를 저장할 컬럼명
	private List<String> skills;
	
	@Column(updatable = false)
	@Temporal(TemporalType.TIMESTAMP)
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	@CreationTimestamp  // insert 시 자동으로 날짜 등록
	private Date regDate;
	
	@Temporal(TemporalType.DATE)
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	@UpdateTimestamp  // update시 자동으로 변경
	private Date updateDate;
	
	
	public Programmer() {
		// TODO Auto-generated constructor stub
	}


	public Programmer(String name, String email, List<String> skills) {
		super();
		this.name = name;
		this.email = email;
		this.skills = skills;
	}
}
