package com.javaroast.jvx440.one_to_one_uni.repository;

import org.springframework.data.repository.CrudRepository;

import com.javaroast.jvx440.one_to_one_uni.LibraryCard;

public interface LibraryCardRepository extends CrudRepository<LibraryCard, String>{

}
