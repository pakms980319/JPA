package com.javaroast.jvx440;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Jvx440Application {

	public static void main(String[] args) {
		SpringApplication.run(Jvx440Application.class, args);
	}

}
