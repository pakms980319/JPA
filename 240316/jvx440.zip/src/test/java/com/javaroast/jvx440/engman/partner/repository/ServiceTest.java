package com.javaroast.jvx440.engman.partner.repository;

//import java.text.ParsePosition;
//import java.text.SimpleDateFormat;
//import java.util.Date;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.Commit;
import org.springframework.transaction.annotation.Transactional;

import com.javaroast.jvx440.RoastTest;
import com.javaroast.jvx440.engman.common.domain.Address.Address;
import com.javaroast.jvx440.engman.common.domain.Address.AddressRepository;
import com.javaroast.jvx440.engman.partners.domain.Partner.Partner;
import com.javaroast.jvx440.engman.partners.domain.Partner.PartnerRepository;
import com.javaroast.jvx440.engman.service.PartnerAddressService;

public class ServiceTest extends RoastTest {
	@Autowired
	PartnerAddressService service;
	
	@Test
	@Transactional
	@Commit
	public void save() {
		Partner partner = new Partner();
		partner.setName("박민석");
		partner.setCrn("1111-222-333");
		partner.setPartnerType(true);
		partner.setPhone("01000000000");
		partner.setHomePage("www.pakms.com");
		partner.setStatus("상태");
		partner.setRepName("박민석");
		
		
		Address address = new Address();
		address.setDistrict("서울");
		address.setAddress1("강남");
		address.setAddress2("강남구");
		address.setPostalCode("43615");
		address.setPartner(partner);
		
//		partner = partnerRepository.save(partner);
		partner.setAddress(address);
		service.addPartner(partner);
//		address = addressRepository.save(address);
	}
	
	@Test
	public void getAllPartners() {
		service.getAllPartnerList().forEach(partner -> System.out.println(partner));
	}
	
	
	@Test
	public void getPartnerById() {
		long partnerId = 1501;
		Optional<Partner> partner = service.getPartnerById(partnerId);
		System.out.println(partner.orElse(null));
	}
	
	
	@Test
	public void getAddressByDistrict() {
		String dist = "대구";
		System.out.println(service.findByDistrict(dist));
	}
	
//	private Date parseDate(String dateStr) {
//		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
//		ParsePosition pos = new ParsePosition(0);
//		return format.parse(dateStr, pos);
//	}
	
	
}
