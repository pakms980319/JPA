package com.javaroast.jvx440;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class RoastTest {

}
