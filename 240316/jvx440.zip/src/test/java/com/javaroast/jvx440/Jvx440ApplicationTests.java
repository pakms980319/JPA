package com.javaroast.jvx440;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Jvx440ApplicationTests {

	@Test
	void contextLoads() {
	}

}
