package com.javaroast.jvx440.exam.sharekey;

import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.Commit;
import org.springframework.transaction.annotation.Transactional;

import com.javaroast.jvx440.RoastTest;

public class MovieServiceTest extends RoastTest {
	@Autowired
	private MovieService movieService;
	
	@Test
	@Transactional
	@Commit
	public void addMovie() {
		Movie movie = new Movie("듄2", null, "SF", "드니빌뢰브", "A, B", parseDate(2024), "사막에서 스파이스를 찾는,", 4L, null);
		System.out.println(parseDate(2024));
		movieService.addMoive(movie);

	}
	
	private Date parseDate(int year) {
		String dateString = String.valueOf(year);
		SimpleDateFormat format = new SimpleDateFormat("yyyy");
		ParsePosition pos = new ParsePosition(0);
		return format.parse(dateString, pos);
	}
}
