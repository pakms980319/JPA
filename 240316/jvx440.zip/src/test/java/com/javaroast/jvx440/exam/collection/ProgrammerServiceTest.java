package com.javaroast.jvx440.exam.collection;

import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.Commit;
import org.springframework.transaction.annotation.Transactional;

import com.javaroast.jvx440.RoastTest;
import com.mysql.cj.x.protobuf.MysqlxDatatypes.Array;

public class ProgrammerServiceTest extends RoastTest {
	@Autowired
	private ProgrammerService programmerService;
	
	@Test
	@Transactional
	@Commit
	public void addProgammer() {
		List<String> skills = Arrays.asList("Java", "Python", "Spring", "JPA");
		Programmer programmer = new Programmer("유비", "yubi@example.com", skills);
		programmerService.addProgrammer(programmer);
	}
	
	@Test
//	@Transactional
	public void getProgrammer() {
		Programmer programmer = programmerService.getProgrammer(3001);
		System.out.println(programmer);
		System.out.println(programmer.getSkills());
	}
	
	@Test
	@Transactional
	@Commit
	public void updateProgrammer1() {
		Programmer programmer = programmerService.modifySkill(1, "Servlet", 3001);
		System.out.println(programmer);
	}
	
	@Test
	@Transactional
	@Commit
	public void updateProgrammer2() {
		List<String> test = Arrays.asList("Java", "JSP", "Spring", "JPA");
		System.out.println(test);
		Programmer programmer = programmerService.modifySkills(test, 3001);
		System.out.println(programmer);
	}
}
