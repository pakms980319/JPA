package com.javaroast.jvx440.one_to_one_bi;

import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.Commit;
import org.springframework.transaction.annotation.Transactional;

import com.javaroast.jvx440.RoastTest;
import com.javaroast.jvx440.exam.one_to_one_bi.LibraryCard;
import com.javaroast.jvx440.exam.one_to_one_bi.LibraryCardRepository;
import com.javaroast.jvx440.exam.one_to_one_bi.LibraryMember;
import com.javaroast.jvx440.exam.one_to_one_bi.LibraryMemberRepository;


public class LibraryServiceTest extends RoastTest{
	@Autowired
	private LibraryCardRepository libraryCardRepo;
	@Autowired
	private LibraryMemberRepository libraryMemberRepo;
	
	@Test
	@Transactional
	@Commit
	public void save() {
		LibraryMember member = new LibraryMember();
		member.setEmail("kwanwoo@example.com");
		member.setName("관우");
		member.setLendingAuth(true);
		member = libraryMemberRepo.save(member);
		
		LibraryCard card = new LibraryCard();
		card.setCardNum("234-56-789");
		card.setOwner(member);
		card.setEnabled(true);
		card.setExpiryDate(parseDate("2028-12-31"));
		libraryCardRepo.save(card);
	}
	
	@Test
	public void getAllCards() {
		libraryCardRepo.findAll().forEach(card -> System.out.println(card));
	}
	
	@Test
	public void getLibraryMember() {
		String MemberEmail = "kwanwoo@example.com";
		Optional<LibraryMember> member = libraryMemberRepo.findById(MemberEmail);
		System.out.println(member.orElse(null));
	}
	
	@Test
	public void getCardByCardNo() {
		String cardNo = "234-56-789";
		Optional<LibraryCard> card = libraryCardRepo.findById(cardNo);
		System.out.println(card.orElse(null));
	}
	
	private Date parseDate(String dateStr) {
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		ParsePosition pos = new ParsePosition(0);
		return format.parse(dateStr, pos);
	}
}
