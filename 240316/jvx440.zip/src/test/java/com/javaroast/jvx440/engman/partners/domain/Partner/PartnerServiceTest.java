package com.javaroast.jvx440.engman.partners.domain.Partner;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.Commit;
import org.springframework.transaction.annotation.Transactional;

import com.javaroast.jvx440.RoastTest;
import com.javaroast.jvx440.engman.common.domain.Address.Address;

public class PartnerServiceTest extends RoastTest {
	@Autowired
	PartnerService service;
	
	@Test
	@Transactional
	@Commit
	public void save() {
		Partner partner = new Partner();
		partner.setName("박민석");
		partner.setCrn("1111-222-333");
		partner.setPartnerType(true);
		partner.setPhone("01000000000");
		partner.setHomePage("www.pakms.com");
		partner.setStatus("상태");
		partner.setRepName("박민석");
				
		Address address = new Address();
		address.setDistrict("서울");
		address.setAddress1("강남");
		address.setAddress2("강남구");
		address.setPostalCode("43615");
		address.setPartner(partner);
		
		PartnerAdditional pAdd = new PartnerAdditional();
		pAdd.setPartnerUri("www.test.com/test");
		pAdd.setAdminId("adminId");
		pAdd.setPasswd("1234");
		pAdd.setPartner(partner);
		
		partner.setAddress(address);
		partner.setPartnerAdditional(pAdd);
		
		service.addPartner(partner);
	}
}
