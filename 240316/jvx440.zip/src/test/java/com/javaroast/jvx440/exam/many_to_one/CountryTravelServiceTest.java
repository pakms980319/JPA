package com.javaroast.jvx440.exam.many_to_one;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.Commit;
import org.springframework.transaction.annotation.Transactional;

import com.javaroast.jvx440.RoastTest;

public class CountryTravelServiceTest extends RoastTest {
	@Autowired
	private CountryTravelService countryTravelService;
	
	@Test
	@Transactional
	@Commit
	public void addCountry() {
		Country country = new Country("대한민국", "Seoul", 50000000);
		country = countryTravelService.addCountry(country);
		System.out.println(country);
	}
	
	@Test
	public void getCountryByName() {
		Country country = countryTravelService.getCountryByName("대한민국");
		System.out.println(country);
	}
	
	@Test
	@Transactional
	@Commit
	public void addCity() {
		Country country = countryTravelService.getCountryByName("대한민국");
		City city = new City(country, "Seoul", "사계절 뚜렷", "경북궁, 서울국립박물관");
		city = countryTravelService.addCity(city);
		System.out.println(city);
	}
	
	@Test
	@Transactional
	@Commit
	public void addCity2() {
		Country country = countryTravelService.getCountryByName("대한민국");
		City city = new City(country, "대구", "아프리카인도 덥다고 함", "팔공산, 두류공원");
		city = countryTravelService.addCity(city);
		System.out.println(city);
		
		City city2 = new City(country, "부산", "해양성 기후", "해운대, 범어사");
		city2 = countryTravelService.addCity(city2);
		System.out.println(city2);
	}
	
	@Test
	public void getCityListByCountryName() {
		List<City> list = countryTravelService.getCityListByCountryName("대한민국");
		System.out.println();
		for (City city : list) {
			System.out.println(city + "\n");
		}
	}
}