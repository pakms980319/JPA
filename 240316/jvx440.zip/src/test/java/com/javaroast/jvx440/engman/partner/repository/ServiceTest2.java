package com.javaroast.jvx440.engman.partner.repository;

public class ServiceTest2 {
	

}
